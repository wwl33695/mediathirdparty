rm -rf MServer*
rm -rf mserver
