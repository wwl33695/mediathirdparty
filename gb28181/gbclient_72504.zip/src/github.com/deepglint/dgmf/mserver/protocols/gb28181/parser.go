package gb28181

import (
	"strings"
)

func ParseRegister1(response string) (realm, nonce, authMethod string, err error) {

	pos := strings.Index(response, "Authenticate")
	if pos < 0 {
		return
	}
	temp := response[pos:]

	templen := len("realm=\"")
	pos = strings.Index(temp, "realm=\"")
	pos1 := strings.Index(temp[pos+templen:], "\"")
	realm = temp[pos+templen : pos+templen+pos1]
	//	println(realm)

	templen = len("nonce=\"")
	pos = strings.Index(temp, "nonce=\"")
	pos1 = strings.Index(temp[pos+templen:], "\"")
	nonce = temp[pos+templen : pos+templen+pos1]
	//	println(nonce)

	templen = len("algorithm=")
	pos = strings.Index(temp, "algorithm=")
	pos1 = strings.Index(temp[pos+templen:], ",")
	authMethod = temp[pos+templen : pos+templen+pos1]
	//	println(authMethod)

	err = nil

	return
}

func ParseResponseHead(response string) (errCode string, err error) {

	pos := strings.Index(response, " ")
	if pos < 0 {
		return
	}

	pos1 := strings.Index(response[pos+1:], " ")
	if pos1 < 0 {
		return
	}

	errCode = response[pos+1 : pos+pos1+1]

	err = nil

	return
}

func MatchResponse(key, response string) bool {
	pos := strings.Index(response, "CSeq:")
	if pos < 0 {
		return false
	}

	pos1 := strings.Index(response[pos:], "\r\n")
	if pos1 < 0 {
		return false
	}

	cseq := response[pos+5:pos+pos1]
//	println(cseq)

	if key == "INVITE" && strings.Contains(cseq, "INVITE") {
		return true
	} else if key == "MESSAGE" && strings.Contains(cseq, "MESSAGE") {
		return true
	} else if key == "REGISTER1" && strings.Contains(cseq, "REGISTER") {
		return true	
	} else if key == "REGISTER2" && strings.Contains(cseq, "REGISTER") {
		return true	
	} else if key == "BYE" && strings.Contains(cseq, "BYE") {
		return true	
	}

	return false
}

func MatchResponseBranchID(branchid, response string) bool {
	pos := strings.Index(response, "branch=")
	if pos < 0 {
		return false
	}

	pos += 7
	pos1 := strings.Index(response[pos:], ";")
	if pos1 < 0 {
		return false
	}

	rbranchid := response[pos:pos+pos1]
//	println(rbranchid)

	if branchid == rbranchid {
		return true
	}

	return false
}

func ParseResponseInvite(response string) (mediaip, mediaport, ssrc, totag string, err error) {

	pos := strings.Index(response, "To:")
	if pos < 0 {
		return
	}

	temp := response[pos+1:]
	pos = strings.Index(temp, "tag=")
	pos1 := strings.Index(temp[pos:], "\r\n")

//	println(pos, pos1)
	totag = temp[pos+4 : pos+pos1]
//	println(totag)

	pos = strings.Index(response, "v=0")
	if pos < 0 {
		return
	}
	temp = response[pos+1:]
	//	println(pos)

	pos = strings.Index(temp, "c=IN IP4 ")
	pos1 = strings.Index(temp[pos+9:], "\r\n")
	if pos1 < 0 {
		pos1 = strings.Index(temp[pos+9:], "\n")		
	}
//	println( pos, pos1)
	mediaip = temp[pos+9 : pos+9+pos1]
//	println(mediaip)

	pos = strings.Index(temp, "m=video ")
	pos1 = strings.Index(temp[pos+8:], " ")
	mediaport = temp[pos+8 : pos+8+pos1]
//	println(mediaport)

	pos = strings.Index(temp, "y=")
	pos1 = strings.Index(temp[pos+2:], "\r\n")
	if pos1 < 0 {
		pos1 = strings.Index(temp[pos+9:], "\n")		
	}
//	println(pos, pos1)
	ssrc = temp[pos+2 : pos+2+pos1]
//	println(ssrc)

	err = nil

	return
}
