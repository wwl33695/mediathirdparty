package utils

const MANUFACTURER = "MServer/1.0.0 (Deep Glint Inc. 2017.4.10)"
