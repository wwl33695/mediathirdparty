
package pio

var RecommendBufioSize = 1024*64

