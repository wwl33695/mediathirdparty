//
// Created by Leo on 2016/11/23.
//

#include "IEncoder.h"

IEncoder::IEncoder() {

}

IEncoder::~IEncoder() {

}