./clean.sh
./make.sh x264
./run.sh
