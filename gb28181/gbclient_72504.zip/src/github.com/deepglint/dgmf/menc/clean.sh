make clean
rm -rf MEnc*
rm -rf run.sh
