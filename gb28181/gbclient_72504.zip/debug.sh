go run main.go -profile -logtostderr=1 -v=4
